"""
Version module for spotdl.
"""

__version__ = "4.2.4"
