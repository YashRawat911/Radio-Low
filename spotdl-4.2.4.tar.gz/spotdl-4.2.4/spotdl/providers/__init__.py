"""
Different types of data providers for spotdl.
"""
