"""
Utility functions for spotdl. These functions are used in every stage of the
download process.
"""
